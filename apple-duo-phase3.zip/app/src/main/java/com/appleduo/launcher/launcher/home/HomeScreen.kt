@file:OptIn(ExperimentalFoundationApi::class)

package com.appleduo.launcher.launcher.home

import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateIntOffsetAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.zIndex
import com.appleduo.launcher.core.design.DuoTheme
import com.appleduo.launcher.core.design.Tokens
import com.appleduo.launcher.core.model.AppInfo
import com.appleduo.launcher.core.model.HomeLayout
import kotlin.math.roundToInt

private const val DOCK_MAX = 6

@Immutable
class HomeActions(
    val onLaunch: (AppInfo) -> Unit,
    val onReorderHome: (List<String>) -> Unit,
    val onHide: (String) -> Unit,
    val onShow: (String) -> Unit,
    val onDockAdd: (String, Int) -> Unit,
    val onDockRemove: (String) -> Unit,
    val onAppInfo: (AppInfo) -> Unit,
)

@Composable
fun HomeScreen(apps: List<AppInfo>, layout: HomeLayout, actions: HomeActions) {
    val colors = DuoTheme.colors
    val byKey = remember(apps) { apps.associateBy { it.key } }
    val homeApps = remember(layout.home, byKey) { layout.home.mapNotNull { byKey[it] } }
    val dockApps = remember(layout.dock, byKey) { layout.dock.mapNotNull { byKey[it] } }
    var editMode by remember { mutableStateOf(false) }
    var showLibrary by remember { mutableStateOf(false) }
    var menuApp by remember { mutableStateOf<AppInfo?>(null) }

    BackHandler(enabled = showLibrary || editMode) {
        if (showLibrary) showLibrary = false else editMode = false
    }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(colors.wallpaperScrim),
    ) {
        val cols = (maxWidth / 88.dp).toInt().coerceIn(4, 12)
        val dockMax = minOf(DOCK_MAX, cols)

        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars)) {
            Box(
                Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 20.dp),
                contentAlignment = Alignment.CenterEnd,
            ) {
                if (editMode) Pill("Done") { editMode = false }
            }

            HomePages(
                apps = homeApps,
                cols = cols,
                editMode = editMode,
                enterEdit = { editMode = true },
                actions = actions,
                openMenu = { menuApp = it },
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .pointerInput(editMode) {
                        var total = 0f
                        detectVerticalDragGestures(
                            onDragStart = { total = 0f },
                            onDragEnd = { if (!editMode && total < -120f) showLibrary = true },
                            onDragCancel = { total = 0f },
                            onVerticalDrag = { _, dy -> total += dy },
                        )
                    },
            )

            Box(Modifier.fillMaxWidth().padding(vertical = 4.dp), contentAlignment = Alignment.Center) {
                Pill("App Library") { showLibrary = true }
            }

            Dock(dockApps, editMode, dockMax, actions) { menuApp = it }
        }

        AnimatedVisibility(
            visible = showLibrary,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) {
            AppLibrary(apps, actions, openMenu = { menuApp = it }, onClose = { showLibrary = false })
        }

        menuApp?.let { app ->
            AppMenu(
                app = app,
                layout = layout,
                dockMax = dockMax,
                actions = actions,
                enterEdit = { showLibrary = false; editMode = true },
                onDismiss = { menuApp = null },
            )
        }
    }
}

@Composable
private fun HomePages(
    apps: List<AppInfo>,
    cols: Int,
    editMode: Boolean,
    enterEdit: () -> Unit,
    actions: HomeActions,
    openMenu: (AppInfo) -> Unit,
    modifier: Modifier,
) {
    BoxWithConstraints(modifier) {
        val indicatorH = 28.dp
        val gridH = maxHeight - indicatorH
        val rows = (gridH / 112.dp).toInt().coerceAtLeast(1)
        val capacity = cols * rows
        val pageCount = maxOf(1, (apps.size + capacity - 1) / capacity)
        val pagerState = rememberPagerState(pageCount = { pageCount })
        var draggingKey by remember { mutableStateOf<String?>(null) }
        val allKeys = remember(apps) { apps.map { it.key } }

        Column {
            HorizontalPager(
                state = pagerState,
                userScrollEnabled = draggingKey == null,
                modifier = Modifier.fillMaxWidth().height(gridH),
            ) { page ->
                val start = page * capacity
                PageGrid(
                    pageApps = apps.drop(start).take(capacity),
                    pageStart = start,
                    allKeys = allKeys,
                    cols = cols,
                    rows = rows,
                    editMode = editMode,
                    draggingKey = draggingKey,
                    setDragging = { draggingKey = it },
                    enterEdit = enterEdit,
                    actions = actions,
                    openMenu = openMenu,
                )
            }
            PageDots(pageCount, pagerState, Modifier.fillMaxWidth().height(indicatorH))
        }
    }
}

private class Live(
    val index: Int,
    val pageStart: Int,
    val cols: Int,
    val rows: Int,
    val cellW: Float,
    val cellH: Float,
    val pageSize: Int,
    val keys: List<String>,
)

@Composable
private fun PageGrid(
    pageApps: List<AppInfo>,
    pageStart: Int,
    allKeys: List<String>,
    cols: Int,
    rows: Int,
    editMode: Boolean,
    draggingKey: String?,
    setDragging: (String?) -> Unit,
    enterEdit: () -> Unit,
    actions: HomeActions,
    openMenu: (AppInfo) -> Unit,
) {
    val haptic = LocalHapticFeedback.current
    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) { detectTapGestures(onLongPress = { enterEdit() }) },
    ) {
        val cellWpx = constraints.maxWidth / cols.toFloat()
        val cellHpx = constraints.maxHeight / rows.toFloat()
        val cellW = maxWidth / cols
        val cellH = maxHeight / rows
        var dragPos by remember { mutableStateOf(Offset.Zero) }

        pageApps.forEachIndexed { index, app ->
            key(app.key) {
                val target = IntOffset(
                    ((index % cols) * cellWpx).roundToInt(),
                    ((index / cols) * cellHpx).roundToInt(),
                )
                val animated by animateIntOffsetAsState(
                    targetValue = target,
                    animationSpec = spring(
                        dampingRatio = Tokens.Motion.springDampingRatio,
                        stiffness = Tokens.Motion.springStiffness,
                    ),
                    label = "cell",
                )
                val dragging = draggingKey == app.key
                val shown = if (dragging) IntOffset(dragPos.x.roundToInt(), dragPos.y.roundToInt()) else animated
                val live by rememberUpdatedState(
                    Live(index, pageStart, cols, rows, cellWpx, cellHpx, pageApps.size, allKeys),
                )

                val gesture = if (editMode) {
                    Modifier.pointerInput(app.key) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = {
                                val l = live
                                dragPos = Offset((l.index % l.cols) * l.cellW, (l.index / l.cols) * l.cellH)
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                setDragging(app.key)
                            },
                            onDragEnd = { setDragging(null) },
                            onDragCancel = { setDragging(null) },
                            onDrag = { change, delta ->
                                change.consume()
                                dragPos += delta
                                val l = live
                                val cx = dragPos.x + l.cellW / 2f
                                val cy = dragPos.y + l.cellH / 2f
                                val col = (cx / l.cellW).toInt().coerceIn(0, l.cols - 1)
                                val row = (cy / l.cellH).toInt().coerceIn(0, l.rows - 1)
                                val idx = (row * l.cols + col).coerceAtMost(l.pageSize - 1)
                                if (idx != l.index) {
                                    val list = l.keys.toMutableList()
                                    list.remove(app.key)
                                    list.add((l.pageStart + idx).coerceIn(0, list.size), app.key)
                                    actions.onReorderHome(list)
                                }
                            },
                        )
                    }
                } else {
                    Modifier.combinedClickable(
                        onClickLabel = "Open ${app.label}",
                        onLongClickLabel = "Show options",
                        onClick = { actions.onLaunch(app) },
                        onLongClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            openMenu(app)
                        },
                    )
                }

                AppIcon(
                    app = app,
                    editMode = editMode,
                    showLabel = true,
                    onRemove = { actions.onHide(app.key) },
                    lifted = dragging,
                    modifier = Modifier
                        .offset { shown }
                        .size(cellW, cellH)
                        .zIndex(if (dragging) 1f else 0f)
                        .then(gesture),
                )
            }
        }
    }
}

@Composable
private fun AppIcon(
    app: AppInfo,
    editMode: Boolean,
    showLabel: Boolean,
    onRemove: (() -> Unit)?,
    modifier: Modifier,
    lifted: Boolean = false,
) {
    val colors = DuoTheme.colors
    val reduceMotion = rememberReduceMotion()
    val rotation = if (editMode && !reduceMotion) {
        val t = rememberInfiniteTransition(label = "wiggle")
        t.animateFloat(
            initialValue = -1.5f,
            targetValue = 1.5f,
            animationSpec = infiniteRepeatable(tween(140, easing = LinearEasing), RepeatMode.Reverse),
            label = "rot",
        ).value
    } else {
        0f
    }

    Box(modifier, contentAlignment = Alignment.TopCenter) {
        Column(
            Modifier
                .padding(top = 6.dp)
                .graphicsLayer {
                    rotationZ = rotation
                    val s = if (lifted) 1.12f else 1f
                    scaleX = s
                    scaleY = s
                },
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box {
                Image(
                    bitmap = app.icon,
                    contentDescription = if (showLabel) null else app.label,
                    modifier = Modifier
                        .padding(6.dp)
                        .size(Tokens.Icon.size)
                        .clip(RoundedCornerShape(Tokens.Radius.icon)),
                )
                if (editMode && onRemove != null) {
                    Box(
                        Modifier
                            .align(Alignment.TopStart)
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF8E8E93))
                            .clickable(onClickLabel = "Remove ${app.label}") { onRemove() },
                        contentAlignment = Alignment.Center,
                    ) {
                        BasicText("–", style = TextStyle(color = Color.White, fontSize = 16.sp))
                    }
                }
            }
            if (showLabel) {
                BasicText(
                    text = app.label,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = TextStyle(
                        color = colors.textPrimary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                    ),
                    modifier = Modifier.padding(horizontal = 4.dp),
                )
            }
        }
    }
}

@Composable
private fun rememberReduceMotion(): Boolean {
    val ctx = LocalContext.current
    return remember {
        Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    }
}

@Composable
private fun PageDots(count: Int, pagerState: PagerState, modifier: Modifier) {
    val c = DuoTheme.colors
    Row(modifier, horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        if (count > 1) {
            repeat(count) { i ->
                Box(
                    Modifier
                        .padding(horizontal = 4.dp)
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(
                            if (i == pagerState.currentPage) c.textPrimary else c.textSecondary.copy(alpha = 0.4f),
                        ),
                )
            }
        }
    }
}

@Composable
private fun Dock(
    apps: List<AppInfo>,
    editMode: Boolean,
    dockMax: Int,
    actions: HomeActions,
    openMenu: (AppInfo) -> Unit,
) {
    val c = DuoTheme.colors
    val haptic = LocalHapticFeedback.current
    val shown = apps.take(dockMax)
    if (shown.isEmpty()) return
    Box(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(
            Modifier
                .widthIn(max = 520.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(Tokens.Radius.surface))
                .background(c.surface)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            shown.forEach { app ->
                key(app.key) {
                    val gesture = if (editMode) {
                        Modifier
                    } else {
                        Modifier.combinedClickable(
                            onClickLabel = "Open ${app.label}",
                            onLongClickLabel = "Show options",
                            onClick = { actions.onLaunch(app) },
                            onLongClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                openMenu(app)
                            },
                        )
                    }
                    AppIcon(
                        app = app,
                        editMode = editMode,
                        showLabel = false,
                        onRemove = { actions.onDockRemove(app.key) },
                        modifier = Modifier.weight(1f).then(gesture),
                    )
                }
            }
        }
    }
}

@Composable
private fun Pill(text: String, onClick: () -> Unit) {
    val c = DuoTheme.colors
    Box(
        Modifier
            .defaultMinSize(minHeight = 44.dp)
            .clip(RoundedCornerShape(50))
            .background(c.surface)
            .clickable(onClickLabel = text, onClick = onClick)
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center,
    ) {
        BasicText(text, style = TextStyle(color = c.textPrimary, fontSize = 15.sp))
    }
}

@Composable
private fun AppLibrary(
    apps: List<AppInfo>,
    actions: HomeActions,
    openMenu: (AppInfo) -> Unit,
    onClose: () -> Unit,
) {
    val c = DuoTheme.colors
    val haptic = LocalHapticFeedback.current
    var query by remember { mutableStateOf("") }
    val results = remember(apps, query) {
        val q = query.trim()
        if (q.isEmpty()) apps else apps.filter { it.label.contains(q, ignoreCase = true) }
    }
    Column(
        Modifier
            .fillMaxSize()
            .background(c.background.copy(alpha = 0.95f))
            .windowInsetsPadding(WindowInsets.systemBars)
            .imePadding(),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BasicTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                textStyle = TextStyle(color = c.textPrimary, fontSize = 17.sp),
                cursorBrush = SolidColor(c.accent),
                modifier = Modifier.weight(1f),
                decorationBox = { inner ->
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(c.surface)
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                    ) {
                        if (query.isEmpty()) {
                            BasicText("Search apps", style = TextStyle(color = c.textSecondary, fontSize = 17.sp))
                        }
                        inner()
                    }
                },
            )
            Spacer(Modifier.width(12.dp))
            Pill("Close", onClose)
        }
        if (results.isEmpty()) {
            Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                BasicText(
                    "No apps match “$query”",
                    style = TextStyle(color = c.textSecondary, fontSize = 15.sp),
                )
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(Tokens.Grid.cellMinWidth),
                contentPadding = PaddingValues(
                    horizontal = Tokens.Grid.horizontalPadding,
                    vertical = Tokens.Grid.verticalPadding,
                ),
                verticalArrangement = Arrangement.spacedBy(Tokens.Grid.rowSpacing),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(results, key = { it.key }) { app ->
                    AppIcon(
                        app = app,
                        editMode = false,
                        showLabel = true,
                        onRemove = null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .combinedClickable(
                                onClickLabel = "Open ${app.label}",
                                onLongClickLabel = "Show options",
                                onClick = {
                                    actions.onLaunch(app)
                                    onClose()
                                },
                                onLongClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    openMenu(app)
                                },
                            ),
                    )
                }
            }
        }
    }
}

@Composable
private fun AppMenu(
    app: AppInfo,
    layout: HomeLayout,
    dockMax: Int,
    actions: HomeActions,
    enterEdit: () -> Unit,
    onDismiss: () -> Unit,
) {
    val c = DuoTheme.colors
    val inDock = app.key in layout.dock
    val onHome = app.key in layout.home
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .widthIn(min = 260.dp)
                .clip(RoundedCornerShape(Tokens.Radius.surface))
                .background(c.background)
                .padding(vertical = 8.dp),
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Image(
                    bitmap = app.icon,
                    contentDescription = null,
                    modifier = Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)),
                )
                Spacer(Modifier.width(12.dp))
                BasicText(
                    app.label,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = TextStyle(color = c.textPrimary, fontSize = 17.sp),
                )
            }
            MenuRow("Edit Home Screen") { enterEdit(); onDismiss() }
            when {
                onHome -> MenuRow("Remove from Home Screen") { actions.onHide(app.key); onDismiss() }
                inDock -> MenuRow("Remove from Dock") { actions.onDockRemove(app.key); onDismiss() }
                else -> MenuRow("Add to Home Screen") { actions.onShow(app.key); onDismiss() }
            }
            if (!inDock && layout.dock.size < dockMax) {
                MenuRow("Add to Dock") { actions.onDockAdd(app.key, dockMax); onDismiss() }
            }
            MenuRow("App Info") { actions.onAppInfo(app); onDismiss() }
        }
    }
}

@Composable
private fun MenuRow(text: String, onClick: () -> Unit) {
    val c = DuoTheme.colors
    BasicText(
        text,
        style = TextStyle(color = c.textPrimary, fontSize = 17.sp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
    )
}
