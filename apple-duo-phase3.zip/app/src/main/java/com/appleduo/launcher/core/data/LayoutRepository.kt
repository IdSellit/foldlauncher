package com.appleduo.launcher.core.data

import android.content.Context
import android.util.Log
import com.appleduo.launcher.core.model.AppInfo
import com.appleduo.launcher.core.model.HomeLayout
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import java.io.File

/** Persists the home layout as a small JSON file (Room arrives later with folders/widgets). */
class LayoutRepository(context: Context) {

    private val file = File(context.filesDir, "layout.json")
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _layout = MutableStateFlow(read())
    val layout: StateFlow<HomeLayout> = _layout.asStateFlow()

    init {
        scope.launch { _layout.drop(1).collect { write(it) } }
    }

    private fun read(): HomeLayout = try {
        if (file.exists()) HomeLayout.fromJson(file.readText()) else HomeLayout()
    } catch (t: Exception) {
        Log.w(TAG, "Layout unreadable, starting fresh", t)
        HomeLayout()
    }

    private fun write(l: HomeLayout) {
        try {
            file.writeText(l.toJson())
        } catch (t: Exception) {
            Log.w(TAG, "Could not save layout", t)
        }
    }

    @Synchronized
    private fun update(block: (HomeLayout) -> HomeLayout) {
        val next = block(_layout.value)
        if (next != _layout.value) _layout.value = next
    }

    /** Drops uninstalled apps, appends newly installed ones, and seeds a first-run layout. */
    fun reconcile(apps: List<AppInfo>) {
        if (apps.isEmpty()) return // never wipe the layout on a transient empty scan
        val allKeys = apps.map { it.key }
        val all = allKeys.toSet()
        update { l ->
            val home = l.home.filter { it in all }
            val dock = l.dock.filter { it in all }
            val hidden = l.hidden.filter { it in all }.toSet()
            if (l.home.isEmpty() && l.dock.isEmpty() && l.hidden.isEmpty()) {
                val d = defaultDock(apps)
                HomeLayout(home = allKeys.filter { it !in d }, dock = d)
            } else {
                val known = (home + dock + hidden).toSet()
                HomeLayout(home + allKeys.filter { it !in known }, dock, hidden)
            }
        }
    }

    fun setHome(keys: List<String>) = update { it.copy(home = keys.distinct()) }

    fun hide(key: String) = update {
        it.copy(home = it.home - key, dock = it.dock - key, hidden = it.hidden + key)
    }

    fun showOnHome(key: String) = update {
        it.copy(home = (it.home - key) + key, dock = it.dock - key, hidden = it.hidden - key)
    }

    fun addToDock(key: String, max: Int) = update {
        if (it.dock.size >= max && key !in it.dock) it
        else it.copy(home = it.home - key, hidden = it.hidden - key, dock = (it.dock - key) + key)
    }

    fun removeFromDock(key: String) = update {
        it.copy(dock = it.dock - key, home = (it.home - key) + key)
    }

    private fun defaultDock(apps: List<AppInfo>): List<String> {
        val picks = LinkedHashSet<String>()
        for (hint in listOf("dialer", "messag", "chrome", "browser", "camera")) {
            apps.firstOrNull { it.packageName.contains(hint, ignoreCase = true) && it.key !in picks }
                ?.let { picks.add(it.key) }
        }
        val chosen = picks.take(4)
        return chosen.ifEmpty { apps.take(4).map { it.key } }
    }

    private companion object {
        const val TAG = "LayoutRepository"
    }
}
