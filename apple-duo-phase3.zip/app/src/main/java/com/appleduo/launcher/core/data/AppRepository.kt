package com.appleduo.launcher.core.data

import android.content.Context
import android.content.pm.LauncherApps
import android.os.Handler
import android.os.Looper
import android.os.UserHandle
import android.os.UserManager
import android.util.Log
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import com.appleduo.launcher.core.model.AppInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Discovers launchable apps through the supported LauncherApps API (no QUERY_ALL_PACKAGES needed)
 * and refreshes automatically when packages are installed, removed, updated or (un)available.
 */
class AppRepository(private val context: Context) {

    private val launcherApps = context.getSystemService(LauncherApps::class.java)
    private val userManager = context.getSystemService(UserManager::class.java)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var refreshJob: Job? = null
    private var started = false

    private val _apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val apps: StateFlow<List<AppInfo>> = _apps.asStateFlow()

    private val callback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String, user: UserHandle) = refresh()
        override fun onPackageAdded(packageName: String, user: UserHandle) = refresh()
        override fun onPackageChanged(packageName: String, user: UserHandle) = refresh()
        override fun onPackagesAvailable(
            packageNames: Array<out String>, user: UserHandle, replacing: Boolean,
        ) = refresh()
        override fun onPackagesUnavailable(
            packageNames: Array<out String>, user: UserHandle, replacing: Boolean,
        ) = refresh()
    }

    fun start() {
        if (started) return
        started = true
        launcherApps.registerCallback(callback, Handler(Looper.getMainLooper()))
        refresh()
    }

    fun refresh() {
        refreshJob?.cancel()
        refreshJob = scope.launch { _apps.value = load() }
    }

    private fun load(): List<AppInfo> {
        val iconPx = ICON_BITMAP_PX
        return userManager.userProfiles
            .flatMap { user ->
                launcherApps.getActivityList(null, user).mapNotNull { info ->
                    try {
                        AppInfo(
                            label = info.label.toString(),
                            component = info.componentName,
                            user = info.user,
                            icon = info.getIcon(0).toBitmap(iconPx, iconPx).asImageBitmap(),
                        )
                    } catch (t: Throwable) {
                        Log.w(TAG, "Skipping ${info.componentName}", t)
                        null
                    }
                }
            }
            .sortedBy { it.label.lowercase() }
    }

    /** Launches an app via its real launch intent. Returns false if it could not be started. */
    fun launch(app: AppInfo): Boolean = try {
        launcherApps.startMainActivity(app.component, app.user, null, null)
        true
    } catch (t: Exception) { // missing/disabled/uninstalled apps, security errors
        Log.w(TAG, "Could not launch ${app.component}", t)
        refresh()
        false
    }

    fun openAppInfo(app: AppInfo) {
        try {
            launcherApps.startAppDetailsActivity(app.component, app.user, null, null)
        } catch (t: Exception) {
            Log.w(TAG, "Could not open app info for ${app.component}", t)
        }
    }

    private companion object {
        const val TAG = "AppRepository"
        const val ICON_BITMAP_PX = 144
    }
}
