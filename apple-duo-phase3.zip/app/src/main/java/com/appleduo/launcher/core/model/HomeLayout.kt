package com.appleduo.launcher.core.model

import org.json.JSONArray
import org.json.JSONObject

/**
 * User layout, independent of screen size. [home] is one flat ordered list that the UI chunks into
 * pages for whatever grid fits the current window, so fold/unfold never loses the user's order.
 */
data class HomeLayout(
    val home: List<String> = emptyList(),
    val dock: List<String> = emptyList(),
    val hidden: Set<String> = emptySet(),
) {
    fun toJson(): String = JSONObject()
        .put("home", JSONArray(home))
        .put("dock", JSONArray(dock))
        .put("hidden", JSONArray(hidden.toList()))
        .toString()

    companion object {
        fun fromJson(text: String): HomeLayout {
            val o = JSONObject(text)
            fun list(name: String): List<String> {
                val a = o.optJSONArray(name) ?: return emptyList()
                return List(a.length()) { a.getString(it) }
            }
            return HomeLayout(list("home"), list("dock"), list("hidden").toSet())
        }
    }
}
