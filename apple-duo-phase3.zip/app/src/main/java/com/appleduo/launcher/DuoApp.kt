package com.appleduo.launcher

import android.app.Application
import com.appleduo.launcher.core.data.AppRepository
import com.appleduo.launcher.core.data.LayoutRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class DuoApp : Application() {
    val appRepository: AppRepository by lazy { AppRepository(this) }
    val layoutRepository: LayoutRepository by lazy { LayoutRepository(this) }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        appRepository.start()
        scope.launch {
            appRepository.apps.collect { apps -> layoutRepository.reconcile(apps) }
        }
    }
}
