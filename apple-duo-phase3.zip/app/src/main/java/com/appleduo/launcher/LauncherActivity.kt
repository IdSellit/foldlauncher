package com.appleduo.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.appleduo.launcher.core.design.DuoThemeProvider
import com.appleduo.launcher.launcher.home.HomeActions
import com.appleduo.launcher.launcher.home.HomeScreen

class LauncherActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val duo = application as DuoApp
        val apps = duo.appRepository
        val layouts = duo.layoutRepository
        setContent {
            DuoThemeProvider {
                val appList by apps.apps.collectAsStateWithLifecycle()
                val layout by layouts.layout.collectAsStateWithLifecycle()
                val actions = remember {
                    HomeActions(
                        onLaunch = { apps.launch(it) },
                        onReorderHome = { layouts.setHome(it) },
                        onHide = { layouts.hide(it) },
                        onShow = { layouts.showOnHome(it) },
                        onDockAdd = { key, max -> layouts.addToDock(key, max) },
                        onDockRemove = { layouts.removeFromDock(it) },
                        onAppInfo = { apps.openAppInfo(it) },
                    )
                }
                HomeScreen(apps = appList, layout = layout, actions = actions)
            }
        }
    }
}
