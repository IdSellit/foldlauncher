# Apple Duo

Apple-inspired foldable launcher for Android (target device: Galaxy Z Fold 8).
Status: **v0.2 - Phase 3 core launcher.**

## Works now (intended)
- HOME registration; install as default launcher.
- Home screen pages (swipe), grid that adapts to window size (fold/unfold/rotate re-flows, order kept).
- Dock (up to 6, fewer on narrow screens), seeded with phone/messages/browser/camera when found.
- Long-press an icon: menu (Edit Home Screen, Remove from Home, Add/Remove Dock, App Info).
- Edit mode (long-press empty space or via menu): icons wiggle, long-press-drag to reorder within a page,
  "-" badge removes from home/dock, "Done" or Back exits.
- App Library: swipe up on the home screen or tap "App Library"; live search; every app.
- Layout persists across restarts (layout.json); new apps appended, removed apps dropped.

## Not yet
Drag across pages / into dock, folders, widgets, wallpaper picker, settings screen, dual-workspace
modes, app pairs, quick panel. See phases 4-7.

## Build
Push to GitHub; the workflow unzips the newest `apple-duo-*.zip` in the repo root and builds the debug APK.
