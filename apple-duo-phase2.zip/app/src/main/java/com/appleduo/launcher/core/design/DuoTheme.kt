package com.appleduo.launcher.core.design

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Immutable
data class DuoColors(
    val background: Color,
    val surface: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val accent: Color,
    val wallpaperScrim: Color,
)

val LightDuoColors = DuoColors(
    background = Color(0xFFF7F5F2),
    surface = Color(0xCCFFFFFF),
    textPrimary = Color(0xFF1C1C1E),
    textSecondary = Color(0xFF6C6C70),
    accent = Color(0xFF0A84FF),
    wallpaperScrim = Color(0x59FFFFFF),
)

val DarkDuoColors = DuoColors(
    background = Color(0xFF000000),
    surface = Color(0xCC2C2C2E),
    textPrimary = Color(0xFFF2F2F7),
    textSecondary = Color(0xFF98989D),
    accent = Color(0xFF0A84FF),
    wallpaperScrim = Color(0x59000000),
)

private val LocalDuoColors = staticCompositionLocalOf { LightDuoColors }

object DuoTheme {
    val colors: DuoColors
        @Composable @ReadOnlyComposable get() = LocalDuoColors.current
}

/** Non-color design tokens. One place to change sizes, radii, spacing and motion. */
object Tokens {
    object Icon {
        val size = 60.dp
    }
    object Radius {
        val icon = 14.dp
        val surface = 24.dp
    }
    object Grid {
        val cellMinWidth = 84.dp
        val horizontalPadding = 20.dp
        val verticalPadding = 16.dp
        val rowSpacing = 12.dp
    }
    object Motion {
        const val durationShortMs = 180
        const val durationMediumMs = 320
        const val springStiffness = 380f
        const val springDampingRatio = 0.85f
    }
}

@Composable
fun DuoThemeProvider(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    CompositionLocalProvider(
        LocalDuoColors provides if (darkTheme) DarkDuoColors else LightDuoColors,
        content = content,
    )
}
