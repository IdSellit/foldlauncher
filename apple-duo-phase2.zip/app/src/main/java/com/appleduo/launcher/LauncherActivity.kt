package com.appleduo.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.appleduo.launcher.core.design.DuoThemeProvider
import com.appleduo.launcher.launcher.home.HomeScreen

class LauncherActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repo = (application as DuoApp).appRepository
        setContent {
            DuoThemeProvider {
                val apps by repo.apps.collectAsStateWithLifecycle()
                HomeScreen(apps = apps, onLaunch = { repo.launch(it) })
            }
        }
    }
}
