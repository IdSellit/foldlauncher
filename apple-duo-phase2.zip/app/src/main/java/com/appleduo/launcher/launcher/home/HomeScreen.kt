package com.appleduo.launcher.launcher.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appleduo.launcher.core.design.DuoTheme
import com.appleduo.launcher.core.design.Tokens
import com.appleduo.launcher.core.model.AppInfo

/** Phase 2 home: a simple adaptive grid proving discovery + launching. Real pages/dock come in Phase 3. */
@Composable
fun HomeScreen(apps: List<AppInfo>, onLaunch: (AppInfo) -> Unit) {
    val colors = DuoTheme.colors
    Box(
        Modifier
            .fillMaxSize()
            .background(colors.wallpaperScrim)
            .windowInsetsPadding(WindowInsets.systemBars),
    ) {
        if (apps.isEmpty()) {
            BasicText(
                text = "No apps found",
                style = TextStyle(color = colors.textSecondary, fontSize = 15.sp),
                modifier = Modifier.align(Alignment.Center),
            )
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(Tokens.Grid.cellMinWidth),
                contentPadding = PaddingValues(
                    horizontal = Tokens.Grid.horizontalPadding,
                    vertical = Tokens.Grid.verticalPadding,
                ),
                verticalArrangement = Arrangement.spacedBy(Tokens.Grid.rowSpacing),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(apps, key = { it.key }) { app -> AppCell(app, onLaunch) }
            }
        }
    }
}

@Composable
private fun AppCell(app: AppInfo, onLaunch: (AppInfo) -> Unit) {
    val colors = DuoTheme.colors
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Tokens.Radius.icon))
            .clickable(onClickLabel = "Open ${app.label}") { onLaunch(app) }
            .padding(vertical = 6.dp),
    ) {
        Image(
            bitmap = app.icon,
            contentDescription = null, // label below carries the accessible name
            modifier = Modifier
                .size(Tokens.Icon.size)
                .clip(RoundedCornerShape(Tokens.Radius.icon)),
        )
        BasicText(
            text = app.label,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = TextStyle(
                color = colors.textPrimary,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
            ),
            modifier = Modifier.padding(top = 6.dp),
        )
    }
}
