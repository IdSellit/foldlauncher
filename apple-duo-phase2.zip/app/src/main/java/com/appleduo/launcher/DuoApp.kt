package com.appleduo.launcher

import android.app.Application
import com.appleduo.launcher.core.data.AppRepository

class DuoApp : Application() {
    val appRepository: AppRepository by lazy { AppRepository(this) }

    override fun onCreate() {
        super.onCreate()
        appRepository.start()
    }
}
